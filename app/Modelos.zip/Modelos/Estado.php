<?php

namespace App\Modelos;

use Illuminate\Database\Eloquent\Model;

class Estado extends Model
{
     protected $table = 'estados';
     protected $primaryKey='id';
     public $timestamps = false;

     public function mascota(){
         return $this->hasOne(Mascota::class, 'id_estado','id');
     }
}
