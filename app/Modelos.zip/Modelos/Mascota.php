<?php

namespace App\Modelos;

use Illuminate\Database\Eloquent\Model;

class Mascota extends Model
{
     protected $table = 'mascotas';
     protected $primaryKey='id';
     public $timestamps = false;

     public function estado(){
         return $this->belongsTo(Estado::class, 'id_estado','id'); 
     }
     public function raza(){
         return $this->belongsTo(Raza::class, 'id_raza','id');
     }
     public function usuario(){
         return $this->belongsTo(Usuario::class, 'id_usuario','id');
     }
     public function extravio(){
         return $this->hasMany(Extravio::class,'id_mascota','id');
     }
}
